<!-- 
Please note that translation contributions should be done on http://translate.pocketmine.net,
not with a pull request. Pull requests with translations will be closed.
-->
